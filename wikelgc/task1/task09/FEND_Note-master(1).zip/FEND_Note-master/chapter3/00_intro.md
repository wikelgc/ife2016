<!-- START doctoc generated TOC please keep comment here to allow auto update -->
<!-- DON'T EDIT THIS SECTION, INSTEAD RE-RUN doctoc TO UPDATE -->
**Table of Contents**  *generated with [DocToc](https://github.com/thlorenz/doctoc)*

- [DOM 编程艺术](#dom-%E7%BC%96%E7%A8%8B%E8%89%BA%E6%9C%AF)

<!-- END doctoc generated TOC please keep comment here to allow auto update -->

# DOM 编程艺术

DOM 编程就是使用 W3C 定义的 API (Application Program Interface)
来操作 HTML 文档
（此处不局限于 HTML，亦可操作 XHTML、XML  等），使用户可以与进行页面交互。
你需要了解节点、属性、样式等基本 DOM 操作，DOM 事件模型，数据存储
(Cookie、Storage) 与数据通信 (Ajax) ，JavaScript 动画，音频、视频、Canvas
等 HTML5 特性，表单、列表操作。
