<!-- START doctoc generated TOC please keep comment here to allow auto update -->
<!-- DON'T EDIT THIS SECTION, INSTEAD RE-RUN doctoc TO UPDATE -->
**Table of Contents**  *generated with [DocToc](https://github.com/thlorenz/doctoc)*

- [书单](#%E4%B9%A6%E5%8D%95)
  - [HTML](#html)
  - [CSS](#css)
  - [JavaScript](#javascript)

<!-- END doctoc generated TOC please keep comment here to allow auto update -->

# 书单

## HTML

N/A

## CSS

- CSS Mastery: Advanced Web Standard Solutions

## JavaScript

- Professional JavaScript for Web Developers
- DOM Scripting: Web Design with JavaScript and the Document Object Model
- AdvancED DOM Scripting: Dynamic Web Design Techniques
- JavaScript: The Definitive Guide

## Version Control

- [Git 简明指南](http://rogerdudler.github.io/git-guide/index.zh.html)
- [Git Pro](https://git-scm.com/book/en/v2)
